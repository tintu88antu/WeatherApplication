﻿using System;
using System.Data;

namespace WeatherApplication.DataLayer
{
    public class WeatherData: IWeatherData
    {
        #region Member Declaration
        private DataTable  weatherDetails;
        #endregion

        #region Constructor
        public WeatherData()
        {
            InitializeDatatable();
        }
        #endregion

        #region Methods
        /// <summary>
        /// Initialize the datatable to save the serach details
        /// </summary>
        private void InitializeDatatable()
        {
            weatherDetails = new DataTable();
            weatherDetails.Columns.Add("City", typeof(string));
            weatherDetails.Columns.Add("Condition", typeof(string));
            weatherDetails.Columns.Add("Temperature", typeof(string));
            weatherDetails.Columns.Add("Humidity", typeof(string));
            weatherDetails.Columns.Add("WindSpeed", typeof(string));
        }

        /// <summary>
        /// save the weather details to dataable and will return the details
        /// </summary>
        /// <param name="city"></param>
        /// <param name="country"></param>
        /// <param name="condition"></param>
        /// <param name="temperarture"></param>
        /// <param name="humidity"></param>
        /// <param name="windspeed"></param>
        /// <returns></returns> 
        public DataTable SaveResponseToGrid(string city, string condition, string temperarture, string humidity, string windspeed)
        {
            if (weatherDetails.Select(string.Format(
                               "City = ('{0}')",
                                city), string.Empty,
                               DataViewRowState.CurrentRows).Length == 0)
            {
                DataRow dataRow = weatherDetails.NewRow();
                dataRow["City"] = city.Trim();
                dataRow["Condition"] = condition;
                dataRow["Temperature"] = temperarture;
                dataRow["Humidity"] = humidity;
                dataRow["WindSpeed"] = windspeed;
                weatherDetails.Rows.Add(dataRow);
            }
            return weatherDetails;            
        }
        #endregion
    }
}
