﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace WeatherApplication.DataLayer
{
    public interface IWeatherData
    {
        DataTable SaveResponseToGrid(string city,string description,
                           string temperature,string humidity,string windSpeed);
    }
}
