﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using WeatherApplication.ServiceLayer.Model;

namespace WeatherApplication.ServiceLayer
{
    public interface IWeatherAPI
    {
      WeatherApiResponse GetWeatherbyCity(string city);
      DataTable SaveResponseToGrid(string city, string description,
                            string temperature, string humidity, string windSpeed);
    }
}
