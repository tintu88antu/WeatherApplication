﻿using System;
using System.Data;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using WeatherApplication.DataLayer;
using WeatherApplication.ServiceLayer.Model;

namespace WeatherApplication.ServiceLayer
{
    public class WeatherAPI: IWeatherAPI
    {
        #region Member Declaration
        public const string AppId = "5bbd093d081705be7f5dde791134728c";
        private HttpClient httpClient;
        private IWeatherData _weatherDataManager;
        #endregion

        #region Constructor
        public WeatherAPI(string apiUrl)
        {
            _weatherDataManager = new WeatherData();
            httpClient = new HttpClient();
            httpClient.BaseAddress = new Uri(apiUrl);
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }
        #endregion

        #region Methods
        /// <summary>
        /// Get the weather details based on city using external api and returns response
        /// </summary>
        /// <param name="city"></param>
        /// <returns></returns>
        public WeatherApiResponse GetWeatherbyCity(string city)
        {
            try
            {
                
                var response =  httpClient.GetAsync(httpClient.BaseAddress + "/data/2.5/weather?q=" + city + "&APPID=" + AppId).Result;
                response.EnsureSuccessStatusCode();
                if (response.IsSuccessStatusCode)
                {
                    var currentWeather =  response.Content.ReadAsStringAsync().Result;
                    return JsonConvert.DeserializeObject<WeatherApiResponse>(currentWeather);

                }
                else
                    return null;

            }
            catch(Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// Save the weather details to datatable and will return details
        /// </summary>
        /// <param name="city"></param>
        /// <param name="country"></param>
        /// <param name="description"></param>
        /// <param name="temperature"></param>
        /// <param name="humidity"></param>
        /// <param name="windSpeed"></param>
        /// <returns></returns>
        public DataTable SaveResponseToGrid(string city,string description,
                            string temperature, string humidity, string windSpeed)
        {
            try
            {
                DataTable weatherRespose = _weatherDataManager.SaveResponseToGrid(city, description, temperature, humidity, windSpeed);
                return weatherRespose;
            }
            catch(Exception ex)
            {
                return null;
            }
        }
        #endregion
    }
}
