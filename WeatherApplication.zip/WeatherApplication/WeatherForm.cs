﻿using System;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using WeatherApplication.ServiceLayer;

namespace WeatherApplication.UILayer
{
    public partial class WeatherForm : Form
    {
        #region Member Declaration       
        private IWeatherAPI _weatherApiManager;
        private string apiUrl = ConfigurationManager.AppSettings["WeatherApi"];
        #endregion

        #region Constructor
        /// <summary>
        /// Initialize the service layer
        /// </summary>
        public WeatherForm()
        {
            this._weatherApiManager = new WeatherAPI(apiUrl);
            InitializeComponent();
        }
        #endregion

        #region Methods
        private void btnSerach_Click(object sender, EventArgs e)
        {
            GetWeatherRespone();
        }

        /// <summary>
        /// Get Weather details based on city
        /// </summary>
        private void GetWeatherRespone()
        {
            try
            {
                var city = cbxCity.Text;
                lblCityValidation.Visible = false;
                var weatherResponse = _weatherApiManager.GetWeatherbyCity(city);
                if (weatherResponse != null)
                {
                    if (!cbxCity.Items.Contains(weatherResponse.name))
                    {
                        cbxCity.Items.Add(weatherResponse.name);
                    }
                    lblCity.Text = weatherResponse.name;
                    lblCountry.Text = weatherResponse.sys.country;
                    picWeatherCondition.Image = GetIconImage(weatherResponse.weather.FirstOrDefault().icon);
                    picWeatherCondition.SizeMode = PictureBoxSizeMode.StretchImage;
                    lblDescription.Text = weatherResponse.weather.FirstOrDefault().description;
                    lblTemperature.Text = (weatherResponse.main.temp - 273.15).ToString() + " °C";
                    lblHumidity.Text = weatherResponse.main.humidity.ToString();
                    lblWindlSpeed.Text = weatherResponse.wind.speed.ToString();
                    pnlWeatherDetails.Visible = true;
                    AddResponseToGrid(weatherResponse.name, lblDescription.Text,
                            lblTemperature.Text, lblHumidity.Text, lblWindlSpeed.Text);
                }
                else
                {
                    lblCityValidation.Visible = true;
                    pnlWeatherDetails.Visible = false;
                    lblCity.Text = "";
                }
            }
            catch (Exception ex)
            {
                pnlWeatherDetails.Visible = false;
            }
        }

        /// <summary>
        /// Save  weather details of the city
        /// </summary>
        /// <param name="city"></param>
        /// <param name="country"></param>
        /// <param name="condition"></param>
        /// <param name="temperature"></param>
        /// <param name="humidity"></param>
        /// <param name="windspeed"></param>
        private void AddResponseToGrid(string city, string condition, string temperature, string humidity, string windspeed)
        {
            DataTable savedWeatherDetails = _weatherApiManager.SaveResponseToGrid(city, condition, temperature, humidity, windspeed);
            dgWeatherDetails.DataSource = savedWeatherDetails;
            dgWeatherDetails.Refresh();
            if (savedWeatherDetails != null && savedWeatherDetails.Rows.Count > 0)
                dgWeatherDetails.Visible = true;
            else
                dgWeatherDetails.Visible = false;
        }

        /// <summary>
        /// Get the image of weather based on the icon
        /// </summary>
        /// <param name="icon"></param>
        /// <returns></returns>
        private Image GetIconImage(string icon)
        {
            try
            {
                return Image.FromFile("../../Pics/" + icon + ".png");
            }
            catch (Exception ex)
            {
                return Image.FromFile("../../Pics/NA.png");
            }
        }
        private void cbxCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetWeatherRespone();
        }
        private void cbxCity_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                GetWeatherRespone();
            }
        }
        #endregion
    }
}
