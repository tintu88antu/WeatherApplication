﻿namespace WeatherApplication.UILayer
{
    partial class WeatherForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WeatherForm));
            this.btnSerach = new System.Windows.Forms.Button();
            this.cbxCity = new System.Windows.Forms.ComboBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblCountry = new System.Windows.Forms.Label();
            this.pnlWeatherDetails = new System.Windows.Forms.Panel();
            this.lblWindlSpeed = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblHumidity = new System.Windows.Forms.Label();
            this.lblTemperature = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.picWeatherCondition = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCityValidation = new System.Windows.Forms.Label();
            this.dgWeatherDetails = new System.Windows.Forms.DataGridView();
            this.pnlWeatherDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picWeatherCondition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgWeatherDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSerach
            // 
            this.btnSerach.Location = new System.Drawing.Point(126, 2);
            this.btnSerach.Name = "btnSerach";
            this.btnSerach.Size = new System.Drawing.Size(50, 21);
            this.btnSerach.TabIndex = 1;
            this.btnSerach.Text = "Search";
            this.btnSerach.UseVisualStyleBackColor = true;
            this.btnSerach.Click += new System.EventHandler(this.btnSerach_Click);
            // 
            // cbxCity
            // 
            this.cbxCity.FormattingEnabled = true;
            this.cbxCity.Location = new System.Drawing.Point(-1, 2);
            this.cbxCity.Name = "cbxCity";
            this.cbxCity.Size = new System.Drawing.Size(121, 21);
            this.cbxCity.TabIndex = 0;
            this.cbxCity.Text = "Enter City";
            this.cbxCity.SelectedIndexChanged += new System.EventHandler(this.cbxCity_SelectedIndexChanged);
            this.cbxCity.KeyUp += new System.Windows.Forms.KeyEventHandler(this.cbxCity_KeyUp);
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.ForeColor = System.Drawing.Color.Azure;
            this.lblCity.Image = global::WeatherApplication.Properties.Resources.panel;
            this.lblCity.Location = new System.Drawing.Point(25, 35);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(34, 13);
            this.lblCity.TabIndex = 5;
            this.lblCity.Text = "lblCity";
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.ForeColor = System.Drawing.Color.Azure;
            this.lblCountry.Image = global::WeatherApplication.Properties.Resources.panel;
            this.lblCountry.Location = new System.Drawing.Point(248, 35);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(53, 13);
            this.lblCountry.TabIndex = 6;
            this.lblCountry.Text = "lblCountry";
            // 
            // pnlWeatherDetails
            // 
            this.pnlWeatherDetails.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pnlWeatherDetails.BackgroundImage = global::WeatherApplication.Properties.Resources.panel;
            this.pnlWeatherDetails.Controls.Add(this.lblWindlSpeed);
            this.pnlWeatherDetails.Controls.Add(this.label3);
            this.pnlWeatherDetails.Controls.Add(this.label2);
            this.pnlWeatherDetails.Controls.Add(this.lblHumidity);
            this.pnlWeatherDetails.Controls.Add(this.lblTemperature);
            this.pnlWeatherDetails.Controls.Add(this.lblDescription);
            this.pnlWeatherDetails.Controls.Add(this.picWeatherCondition);
            this.pnlWeatherDetails.Controls.Add(this.label1);
            this.pnlWeatherDetails.Controls.Add(this.lblCity);
            this.pnlWeatherDetails.Controls.Add(this.lblCountry);
            this.pnlWeatherDetails.Location = new System.Drawing.Point(38, 70);
            this.pnlWeatherDetails.Name = "pnlWeatherDetails";
            this.pnlWeatherDetails.Size = new System.Drawing.Size(324, 212);
            this.pnlWeatherDetails.TabIndex = 7;
            this.pnlWeatherDetails.Visible = false;
            // 
            // lblWindlSpeed
            // 
            this.lblWindlSpeed.AutoSize = true;
            this.lblWindlSpeed.ForeColor = System.Drawing.Color.Azure;
            this.lblWindlSpeed.Image = global::WeatherApplication.Properties.Resources.panel;
            this.lblWindlSpeed.Location = new System.Drawing.Point(140, 187);
            this.lblWindlSpeed.Name = "lblWindlSpeed";
            this.lblWindlSpeed.Size = new System.Drawing.Size(70, 13);
            this.lblWindlSpeed.TabIndex = 14;
            this.lblWindlSpeed.Text = "lblwindSpeed";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.label3.Image = global::WeatherApplication.Properties.Resources.panel;
            this.label3.Location = new System.Drawing.Point(25, 187);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Wind Speed";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Azure;
            this.label2.Image = global::WeatherApplication.Properties.Resources.panel;
            this.label2.Location = new System.Drawing.Point(25, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Humidity";
            // 
            // lblHumidity
            // 
            this.lblHumidity.AutoSize = true;
            this.lblHumidity.ForeColor = System.Drawing.Color.Azure;
            this.lblHumidity.Image = global::WeatherApplication.Properties.Resources.panel;
            this.lblHumidity.Location = new System.Drawing.Point(140, 157);
            this.lblHumidity.Name = "lblHumidity";
            this.lblHumidity.Size = new System.Drawing.Size(57, 13);
            this.lblHumidity.TabIndex = 11;
            this.lblHumidity.Text = "lblHumidity";
            // 
            // lblTemperature
            // 
            this.lblTemperature.AutoSize = true;
            this.lblTemperature.ForeColor = System.Drawing.Color.Azure;
            this.lblTemperature.Image = global::WeatherApplication.Properties.Resources.panel;
            this.lblTemperature.Location = new System.Drawing.Point(144, 97);
            this.lblTemperature.Name = "lblTemperature";
            this.lblTemperature.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblTemperature.Size = new System.Drawing.Size(77, 13);
            this.lblTemperature.TabIndex = 10;
            this.lblTemperature.Text = "lblTemperature";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblDescription.ForeColor = System.Drawing.Color.Azure;
            this.lblDescription.Image = global::WeatherApplication.Properties.Resources.panel;
            this.lblDescription.Location = new System.Drawing.Point(144, 69);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(70, 13);
            this.lblDescription.TabIndex = 9;
            this.lblDescription.Text = "lblDescription";
            // 
            // picWeatherCondition
            // 
            this.picWeatherCondition.BackColor = System.Drawing.Color.White;
            this.picWeatherCondition.Location = new System.Drawing.Point(18, 69);
            this.picWeatherCondition.Name = "picWeatherCondition";
            this.picWeatherCondition.Size = new System.Drawing.Size(79, 72);
            this.picWeatherCondition.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picWeatherCondition.TabIndex = 8;
            this.picWeatherCondition.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Azure;
            this.label1.Image = global::WeatherApplication.Properties.Resources.panel;
            this.label1.Location = new System.Drawing.Point(101, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Weather Details";
            // 
            // lblCityValidation
            // 
            this.lblCityValidation.AutoSize = true;
            this.lblCityValidation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCityValidation.ForeColor = System.Drawing.Color.Red;
            this.lblCityValidation.Location = new System.Drawing.Point(-4, 26);
            this.lblCityValidation.Name = "lblCityValidation";
            this.lblCityValidation.Size = new System.Drawing.Size(136, 13);
            this.lblCityValidation.TabIndex = 8;
            this.lblCityValidation.Text = "Please Enter Valid City";
            this.lblCityValidation.Visible = false;
            // 
            // dgWeatherDetails
            // 
            this.dgWeatherDetails.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dgWeatherDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgWeatherDetails.GridColor = System.Drawing.SystemColors.Control;
            this.dgWeatherDetails.Location = new System.Drawing.Point(38, 305);
            this.dgWeatherDetails.Name = "dgWeatherDetails";
            this.dgWeatherDetails.Size = new System.Drawing.Size(510, 167);
            this.dgWeatherDetails.TabIndex = 2;
            this.dgWeatherDetails.Visible = false;
            // 
            // WeatherForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 516);
            this.Controls.Add(this.dgWeatherDetails);
            this.Controls.Add(this.lblCityValidation);
            this.Controls.Add(this.pnlWeatherDetails);
            this.Controls.Add(this.cbxCity);
            this.Controls.Add(this.btnSerach);
            this.Name = "WeatherForm";
            this.Text = "Weather Form";
            this.pnlWeatherDetails.ResumeLayout(false);
            this.pnlWeatherDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picWeatherCondition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgWeatherDetails)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSerach;
        private System.Windows.Forms.ComboBox cbxCity;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.Panel pnlWeatherDetails;
        private System.Windows.Forms.PictureBox picWeatherCondition;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblHumidity;
        private System.Windows.Forms.Label lblTemperature;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblWindlSpeed;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCityValidation;
        private System.Windows.Forms.DataGridView dgWeatherDetails;
    }
}

